<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>calendar</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
    
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<box-icon name="rocket"></box-icon>
</body>
</html>